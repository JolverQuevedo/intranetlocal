barcode.asp is used to display the actual barcode.
fontimport.asp is used to generate new font files.

See the comments in both files for usage information.