Title: Pure ASP Barcode Generator Version 2
Description: Generates an barcode in ASP without any com+ components or groups of images.
Currently supports the following code types: UPC-A, code39, code128b, ean-13, postnet, planet.
Also now supports text in the barcode image (which is why I'm reposting this as V2. I've had about 100 requests for font support.). Currently has 10px & 12px Courier New fonts, but new fonts are easy to import with the provided script.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=8817&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
